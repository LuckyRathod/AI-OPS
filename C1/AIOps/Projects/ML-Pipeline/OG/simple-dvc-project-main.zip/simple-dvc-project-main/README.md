# simple-dvc-project
simple-dvc-project is about giving dem of automating ML pipelines

## important commands-
refer at [this link](others/imp_commands.md)

## wokflow -
<img src="others/imgs/simple-workflow-01@2x.png" alt="workflow" width="70%">

## Important references -

* [Python logging module](https://docs.python.org/3/library/logging.html)